package bibliotecaetitc;

/**
 * Clase que representa un libro dentro de la biblioteca.
 * Hereda de MaterialBibliografico y añade un atributo propio: género.
 * Aplica herencia y polimorfismo.
 */
public class Libro extends MaterialBibliografico {

    private String genero; // Género o categoría del libro

    /**
     * Constructor que inicializa los datos del libro, incluyendo el género.
     */
    public Libro(String codigo, String titulo, String autor, String genero) {
        super(codigo, titulo, autor); // Llamado al constructor de la clase padre
        this.genero = genero;
    }

    /**
     * Método sobrescrito que muestra la información del libro.
     * Ejemplo de polimorfismo: este método reemplaza el comportamiento del método original.
     */
    @Override
    public void mostrarInfo() {
        System.out.println("📘 [LIBRO] Codigo: " + codigo +
                " | Titulo: " + titulo +
                " | Autor: " + autor +
                " | Genero: " + genero +
                " | Disponible: " + (disponible ? "Si" : "No"));
    }
}
