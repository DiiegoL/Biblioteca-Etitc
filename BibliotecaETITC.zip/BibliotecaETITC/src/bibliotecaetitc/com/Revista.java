package bibliotecaetitc;

/**
 * Clase que representa una revista.
 * Hereda de MaterialBibliografico y añade un atributo propio: número de edición.
 * Aplica herencia y polimorfismo al sobrescribir el método mostrarInfo().
 */
public class Revista extends MaterialBibliografico {

    private int numeroEdicion; // Número de edición de la revista

    /**
     * Constructor que inicializa los datos de la revista.
     */
    public Revista(String codigo, String titulo, String autor, int numeroEdicion) {
        super(codigo, titulo, autor);
        this.numeroEdicion = numeroEdicion;
    }

    /**
     * Método sobrescrito que muestra la información específica de una revista.
     */
    @Override
    public void mostrarInfo() {
        System.out.println("📰 [REVISTA] Codigo: " + codigo +
                " | Titulo: " + titulo +
                " | Autor: " + autor +
                " | Edicion N°: " + numeroEdicion +
                " | Disponible: " + (disponible ? "Si" : "No"));
    }
}
