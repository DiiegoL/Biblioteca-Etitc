package bibliotecaetitc;

/**
 * Clase base que representa cualquier material bibliográfico de la biblioteca.
 * Contiene los atributos y métodos comunes que comparten libros, revistas u otros materiales.
 * Aplica los principios de encapsulación y abstracción.
 */
public class MaterialBibliografico {

    // Atributos protegidos para que puedan ser heredados por las subclases
    protected String codigo;
    protected String titulo;
    protected String autor;
    protected boolean disponible;

    /**
     * Constructor que inicializa los datos básicos del material.
     */
    public MaterialBibliografico(String codigo, String titulo, String autor) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.autor = autor;
        this.disponible = true; // Por defecto, el material está disponible
    }

    /**
     * Devuelve el código del material.
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * Indica si el material está disponible para préstamo.
     */
    public boolean isDisponible() {
        return disponible;
    }

    /**
     * Cambia el estado del material a "no disponible".
     */
    public void prestar() {
        disponible = false;
    }

    /**
     * Cambia el estado del material a "disponible".
     */
    public void devolver() {
        disponible = true;
    }

    /**
     * Muestra la información general del material.
     * Este método puede ser sobrescrito en las subclases (polimorfismo).
     */
    public void mostrarInfo() {
        System.out.println("Codigo: " + codigo +
                " | Titulo: " + titulo +
                " | Autor: " + autor +
                " | Disponible: " + (disponible ? "Si" : "No"));
    }
}
