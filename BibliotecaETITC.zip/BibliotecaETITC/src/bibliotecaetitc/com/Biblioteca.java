package bibliotecaetitc;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Clase que gestiona los materiales de la biblioteca.
 * Se encarga de las operaciones principales como el inventario, los préstamos,
 * las devoluciones y la visualización de multas.
 * Demuestra el uso del polimorfismo al trabajar con una lista de tipo MaterialBibliografico.
 */
public class Biblioteca {

    // Lista que almacena los diferentes materiales bibliográficos
    private ArrayList<MaterialBibliografico> materiales;
    private Scanner sc;

    /**
     * Constructor que inicializa la lista de materiales con algunos ejemplos.
     */
    public Biblioteca() {
        materiales = new ArrayList<>();
        sc = new Scanner(System.in);

        // Carga inicial de materiales (libros y revistas)
        materiales.add(new Libro("L001", "El Quijote", "Miguel de Cervantes", "Novela"));
        materiales.add(new Libro("L002", "Clean Code", "Robert C. Martin", "Programacion"));
        materiales.add(new Revista("R001", "National Geographic", "Varios", 256));
    }

    /**
     * Muestra todos los materiales disponibles en la biblioteca.
     * Cada objeto ejecuta su propia versión de mostrarInfo() (polimorfismo).
     */
    public void mostrarInventario() {
        System.out.println("\n--- Inventario de Materiales ---");
        for (MaterialBibliografico m : materiales) {
            m.mostrarInfo();
        }
    }

    /**
     * Realiza el préstamo de un material según su código.
     * Cambia su estado a "no disponible" si el material está libre.
     */
    public void prestarMaterial() {
        System.out.print("Ingrese el codigo del material: ");
        String codigo = sc.nextLine();

        for (MaterialBibliografico m : materiales) {
            if (m.getCodigo().equalsIgnoreCase(codigo)) {
                if (m.isDisponible()) {
                    m.prestar();
                    System.out.println("✅ Prestamo realizado con exito.");
                } else {
                    System.out.println("⚠️ Este material ya esta prestado.");
                }
                return;
            }
        }
        System.out.println("❌ Codigo no encontrado.");
    }

    /**
     * Registra la devolución de un material, cambiando su estado a disponible.
     */
    public void devolverMaterial() {
        System.out.print("Ingrese el codigo del material: ");
        String codigo = sc.nextLine();

        for (MaterialBibliografico m : materiales) {
            if (m.getCodigo().equalsIgnoreCase(codigo)) {
                if (!m.isDisponible()) {
                    m.devolver();
                    System.out.println("📗 Devolucion registrada correctamente.");
                } else {
                    System.out.println("⚠️ Este material ya estaba disponible.");
                }
                return;
            }
        }
        System.out.println("❌ Codigo no encontrado.");
    }

    /**
     * Muestra la información de las multas del sistema.
     * (Versión simplificada sin cálculo de fechas).
     */
    public void mostrarMultas() {
        System.out.println("💰 Sistema de multas:");
        System.out.println("Cada dia de retraso genera una multa de $1000.");
        System.out.println("(Esta version no calcula dias reales)");
    }
}
