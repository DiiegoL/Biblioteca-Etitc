package bibliotecaetitc;

import java.util.Scanner;

/**
 * Clase principal que contiene el método main.
 * Muestra un menú interactivo que permite al usuario acceder
 * a las funciones principales de la biblioteca.
 */
public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Biblioteca biblioteca = new Biblioteca();
        int opcion;

        // Bucle que mantiene el menú activo hasta que el usuario elige salir
        do {
            System.out.println("\n===== MENU BIBLIOTECA ETITC =====");
            System.out.println("1. Inventario");
            System.out.println("2. Prestamo");
            System.out.println("3. Devolucion");
            System.out.println("4. Multas");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opcion: ");

            opcion = sc.nextInt();
            sc.nextLine(); // Limpieza del buffer

            // Uso de switch para determinar la acción a ejecutar
            switch (opcion) {
                case 1 -> biblioteca.mostrarInventario();
                case 2 -> biblioteca.prestarMaterial();
                case 3 -> biblioteca.devolverMaterial();
                case 4 -> biblioteca.mostrarMultas();
                case 5 -> System.out.println("👋 Gracias por usar la Biblioteca ETITC.");
                default -> System.out.println("⚠️ Opcion no valida. Intente de nuevo.");
            }
        } while (opcion != 5);

        // Cierre del escáner como buena práctica
        sc.close();
    }
}
